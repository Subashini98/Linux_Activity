#ifndef __MYSTRING_H
#define __MYSTRING_H
  int mystrlen(char str[100]);
  void mystrcpy(char a[100], char b[100]);
  void mystrcat(char p[100], char q[100]);
  void mystrcmp(char str1[100], char str2[100]);
#endif
